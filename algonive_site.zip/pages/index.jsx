// Homepage with About Us included
export default function Home() { return <div>ALGONIVE HOMEPAGE</div>; }